# -*- coding: utf-8 -*-
 
"""
phuego.__main__: executed when the phuego directory is called as script.
"""

from .main import main

main()